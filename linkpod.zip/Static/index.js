var fs = require('fs');
let auth = '../Script/auth.js';
let index = '../Script/index.js';
let service = '../Script/service.js';
let extractURN = '../Script/ExtractURN.js';


let date = new Date();
console.log(date)


// fs.unlink(path, function (err) {
//     if (err) throw err;
//     console.log('File deleted!');
// }); 